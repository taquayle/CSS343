#include "Borrow.h"



Borrow::Borrow()
{
}


Borrow::~Borrow()
{
}


bool Borrow::executeCommand(std::vector<Customer*> &, std::vector<Movie*> &)
{
	return false;
}
